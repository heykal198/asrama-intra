define(function() {
	return (/[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/).source;
});
